package com.camilo.moneyware.service;

import java.util.Optional;

import javax.persistence.PersistenceException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.camilo.moneyware.model.Categoria;
import com.camilo.moneyware.repository.Categorias;
import com.camilo.moneyware.service.exception.CategoriaJaCadastradaException;
import com.camilo.moneyware.service.exception.ImpossivelExcluirEntidadeException;

@Service
public class CadastroCategoriaService {
	
	@Autowired
	private Categorias categorias;
	
	@Transactional
	public Categoria salvar(Categoria categoria) {
		Optional<Categoria> categoriaOptional = categorias.findByNomeIgnoreCase(categoria.getNome());
		if (categoriaOptional.isPresent()) {
			System.out.println("deu merda!");
			throw new CategoriaJaCadastradaException("Esta categoria já está cadastrada!");
		}

		return categorias.saveAndFlush(categoria);
	}
	
	@Transactional
	public void excluir(Categoria categoria) {
		try {
			categorias.delete(categoria);
			categorias.flush();
		}
		catch (PersistenceException e) {
			throw new ImpossivelExcluirEntidadeException(e.getLocalizedMessage());
		}
	}	
}
