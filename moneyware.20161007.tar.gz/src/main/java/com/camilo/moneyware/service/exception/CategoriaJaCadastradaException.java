package com.camilo.moneyware.service.exception;

public class CategoriaJaCadastradaException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
	public CategoriaJaCadastradaException(String message) {
		super(message);
	}

}