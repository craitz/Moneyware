package com.camilo.moneyware.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.camilo.moneyware.model.Despesa;
import com.camilo.moneyware.repository.helper.despesa.DespesasQueries;

public interface Despesas extends JpaRepository<Despesa, Long>, DespesasQueries {

}
