package com.camilo.moneyware.service;

import javax.persistence.PersistenceException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.camilo.moneyware.model.Despesa;
import com.camilo.moneyware.repository.Despesas;
import com.camilo.moneyware.service.exception.ImpossivelExcluirEntidadeException;

@Service
public class CadastroDespesaService {

	@Autowired
	private Despesas despesas;

	@Transactional
	public void salvar(Despesa despesa) {
		despesas.save(despesa);
	}

	@Transactional
	public void excluir(Despesa despesa) {
		try {
			despesas.delete(despesa);
			despesas.flush();
		}
		catch (PersistenceException e) {
			throw new ImpossivelExcluirEntidadeException("Erro ao excluir a despesa!");
		}
	}
}
