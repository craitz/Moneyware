package com.camilo.moneyware.repository.helper.categoria;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.camilo.moneyware.model.Categoria;
import com.camilo.moneyware.repository.filter.CategoriaFilter;

public interface CategoriasQueries {

	public Page<Categoria> filtrar(CategoriaFilter filtro, Pageable pageable);

	public Long getNumeroTotal();
}
