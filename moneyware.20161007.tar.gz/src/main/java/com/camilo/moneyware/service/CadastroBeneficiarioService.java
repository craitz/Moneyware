package com.camilo.moneyware.service;

import java.util.Optional;

import javax.persistence.PersistenceException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.camilo.moneyware.model.Beneficiario;
import com.camilo.moneyware.repository.Beneficiarios;
import com.camilo.moneyware.service.exception.BeneficiarioJaCadastradoException;
import com.camilo.moneyware.service.exception.ImpossivelExcluirEntidadeException;

@Service
public class CadastroBeneficiarioService {
	
	@Autowired
	private Beneficiarios beneficiarios;
	
	@Transactional
	public Beneficiario salvar(Beneficiario beneficiario) {
		Optional<Beneficiario> beneficiarioOptional = beneficiarios.findByNomeIgnoreCase(beneficiario.getNome());
		if (beneficiarioOptional.isPresent()) {
			throw new BeneficiarioJaCadastradoException("Este beneficiario já está cadastrado!");
		}

		return beneficiarios.saveAndFlush(beneficiario);
	}
	
	@Transactional
	public void excluir(Beneficiario beneficiario) {
		try {
			beneficiarios.delete(beneficiario);
			beneficiarios.flush();
		}
		catch (PersistenceException e) {
			throw new ImpossivelExcluirEntidadeException(e.getLocalizedMessage());
		}
	}	
}
