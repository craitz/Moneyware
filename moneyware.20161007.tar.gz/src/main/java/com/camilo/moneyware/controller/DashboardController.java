package com.camilo.moneyware.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.camilo.moneyware.model.Usuario;
import com.camilo.moneyware.repository.Beneficiarios;
import com.camilo.moneyware.repository.Categorias;
import com.camilo.moneyware.repository.Despesas;
import com.camilo.moneyware.repository.Usuarios;

@Controller
public class DashboardController {
	
	@Autowired
	private Categorias categorias;

	@Autowired
	private Usuarios usuarios;

	@Autowired
	private Beneficiarios beneficiarios;

	@Autowired
	private Despesas despesas;

	@GetMapping("/")
	public ModelAndView dashboard(Principal principal) {
		ModelAndView mv = new ModelAndView("Dashboard");
		
		//seta o usuário  logado no filtro
		Usuario usuarioAutenticado = usuarios.findByEmail(principal.getName()).get();
		
		mv.addObject("ultimaSemana", despesas.getTotalSemana(usuarioAutenticado.getCodigo()));
		mv.addObject("mediaTrimestre", despesas.getMedia(3, usuarioAutenticado.getCodigo()));
		mv.addObject("mediaSemestre", despesas.getMedia(6, usuarioAutenticado.getCodigo()));
		mv.addObject("mediaAno", despesas.getMedia(12, usuarioAutenticado.getCodigo()));
		mv.addObject("totalDespesaMes", despesas.getTotalMesAtual(usuarioAutenticado.getCodigo()));
		mv.addObject("totalBeneficiarios", beneficiarios.getNumeroTotal());
		mv.addObject("totalCategorias", categorias.getNumeroTotal());
		mv.addObject("totalUsuarios", usuarios.getNumeroTotal());
		mv.addObject("totalUsuariosAtivos", usuarios.getNumeroTotalPorStatus(true));
		mv.addObject("totalUsuariosInativos", usuarios.getNumeroTotalPorStatus(false));
		
		return mv;
	}
	
	@GetMapping("/cyborg")
	public String cyborg() {
		return "cyborg/layout-cyborg";
	}	
}
