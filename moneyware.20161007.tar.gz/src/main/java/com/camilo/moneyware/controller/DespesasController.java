package com.camilo.moneyware.controller;

import java.math.BigDecimal;
import java.security.Principal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.camilo.moneyware.controller.page.PageWrapper;
import com.camilo.moneyware.dto.DespesaCategoria;
import com.camilo.moneyware.dto.DespesaMes;
import com.camilo.moneyware.model.Despesa;
import com.camilo.moneyware.model.Usuario;
import com.camilo.moneyware.repository.Beneficiarios;
import com.camilo.moneyware.repository.Categorias;
import com.camilo.moneyware.repository.Despesas;
import com.camilo.moneyware.repository.Usuarios;
import com.camilo.moneyware.repository.filter.DespesaFilter;
import com.camilo.moneyware.service.CadastroDespesaService;
import com.camilo.moneyware.service.exception.ImpossivelExcluirEntidadeException;

@Controller
@RequestMapping("/despesas")
public class DespesasController {

	@Autowired
	private CadastroDespesaService cadastroDespesaService;
	
	@Autowired
	private Despesas despesas;

	@Autowired
	private Categorias categorias;

	@Autowired
	private Beneficiarios beneficiarios;
	
	@Autowired
	private Usuarios usuarios;

	@GetMapping(value = "/novo")	
	public ModelAndView novo(Despesa despesa, Principal principal) {
		ModelAndView mv = new ModelAndView("despesa/CadastroDespesa");
		
		mv.addObject("categorias", categorias.findAllByOrderByNomeAsc());
		mv.addObject("beneficiarios", beneficiarios.findAllByOrderByNomeAsc());
		
		//seta o dia de hoje, se for uma nova despesa
		if (despesa.isNova()) {
			despesa.setData(LocalDate.now());
		}

		
		return mv;
	}

	@RequestMapping(value = { "/nova", "{\\d+}" }, method = RequestMethod.POST)
	public ModelAndView salvar(@Validated Despesa despesa, BindingResult result, Model model, RedirectAttributes attr, Principal principal) {

		if (result.hasErrors()) {
			return novo(despesa, principal);
		}
	
		//pega o usuário logado e seta para a nova despesa
		if (despesa.isNova()) {
			Optional<Usuario> usuarioLogado = usuarios.findByEmail(principal.getName());
			if (usuarioLogado.isPresent()) {
				despesa.setUsuario(usuarioLogado.get());
			}
		}
		
		cadastroDespesaService.salvar(despesa);
		attr.addFlashAttribute("mensagem", "Despesa salvo com sucesso!");

		return new ModelAndView("redirect:/despesas/novo");
	}
	
	@GetMapping
	public ModelAndView pesquisar(DespesaFilter despesaFilter, BindingResult result, @PageableDefault(size = 10) Pageable pageable, HttpServletRequest httpServletRequest) {
		ModelAndView mv = new ModelAndView("despesa/PesquisaDespesas");

		//pega o usuario logado
		Usuario usuarioAutenticado = usuarios.findByEmail(httpServletRequest.getUserPrincipal().getName()).get();

		//seta o usuário  logado no filtro
		despesaFilter.setUsuario(usuarioAutenticado);
		
		mv.addObject("categorias", categorias.findAllByOrderByNomeAsc());
		mv.addObject("beneficiarios", beneficiarios.findAllByOrderByNomeAsc());
		
		BigDecimal valotTotal = despesas.valorTotal(despesaFilter);
		mv.addObject("total", valotTotal);
		
		PageWrapper<Despesa> paginaWrapper = new PageWrapper<>(despesas.filtrar(despesaFilter, pageable), httpServletRequest);
		mv.addObject("pagina", paginaWrapper);
		
//		BigDecimal total = BigDecimal.ZERO;
//		List<Despesa> despesasFiltradas = paginaWrapper.getConteudo();
//		for (Despesa despesa : despesasFiltradas) {
//			total = total.add(despesa.getValor());
//		}
//		mv.addObject("total", total);
		
		return mv;
	}

	@DeleteMapping("/{codigo}")
	public @ResponseBody ResponseEntity<?> excluir(@PathVariable("codigo") Despesa despesa) {
		try {
			cadastroDespesaService.excluir(despesa);
		} catch (ImpossivelExcluirEntidadeException e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
		return ResponseEntity.ok().build();
	}
	
	@GetMapping("/{codigo}")
	public ModelAndView editar(@PathVariable("codigo") Despesa despesa, Principal principal) {
		ModelAndView mv = novo(despesa, principal);
		mv.addObject(despesa);
		return mv;
	}
	
	@GetMapping("/totalPorMes")
	public @ResponseBody List<DespesaMes> listarTotalDespesaPorMes(Principal principal) {
		//seta o usuário  logado no filtro
		Usuario usuarioAutenticado = usuarios.findByEmail(principal.getName()).get();

		return despesas.totalPorMes(usuarioAutenticado.getCodigo());
	}	
	
	@GetMapping("/totalPorCategoria/{mes}")
	public @ResponseBody List<DespesaCategoria> listarTotalDespesaPorCategoria(@PathVariable("mes") Integer mes, Principal principal) {
		
		//seta o usuário  logado no filtro
		Usuario usuarioAutenticado = usuarios.findByEmail(principal.getName()).get();

		return despesas.totalPorCategoria(usuarioAutenticado.getCodigo(), mes);
	}		

	@GetMapping("/totalMes/{mes}")
	public @ResponseBody BigDecimal listarTotalDespesaPorMes(@PathVariable("mes") Integer mes, Principal principal) {
		
		//seta o usuário  logado no filtro
		Usuario usuarioAutenticado = usuarios.findByEmail(principal.getName()).get();

		return despesas.getTotalMes(usuarioAutenticado.getCodigo(), mes);
	}		
}
