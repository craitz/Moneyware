var moneyware = moneyware || {};

moneyware.MaskMoney = (function() {

	function MaskMoney() {
		this.decimal = $('.js-decimal');
	}

	MaskMoney.prototype.enable = function() {
		this.decimal.maskNumber({ decimal: ',', thousands: '.' });
	}

	return MaskMoney;
})();

moneyware.MaskDate = (function() {

	function MaskDate() {
		this.inputDate = $('.js-date');
	}

	MaskDate.prototype.enable = function() {
		this.inputDate.mask('00/00/0000');
		this.inputDate.datepicker({
			orientation : 'bottom',
			language : 'pt-BR',
			autoclose : true,
			todayHighlight : true,
			clearBtn : true
		});
	}

	return MaskDate;
}());

moneyware.Security = (function() {

	function Security() {
		this.token = $('input[name=_csrf]').val();
		this.header = $('input[name=_csrf_header]').val();
	}

	Security.prototype.enable = function() {
		$(document).ajaxSend(function(event, jqxhr, settings) {
			jqxhr.setRequestHeader(this.header, this.token);
		}.bind(this));
	}

	return Security;

}());

$(function() {
	var maskMoney = new moneyware.MaskMoney();
	maskMoney.enable();

	var maskDate = new moneyware.MaskDate();
	maskDate.enable();

	var security = new moneyware.Security();
	security.enable();
});