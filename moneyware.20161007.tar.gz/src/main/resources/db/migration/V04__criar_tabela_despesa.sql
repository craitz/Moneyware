CREATE TABLE despesa (
    codigo BIGINT(20) PRIMARY KEY AUTO_INCREMENT,
	valor DECIMAL(10, 2) NOT NULL,
	data DATETIME NOT NULL,
    descricao TEXT DEFAULT NULL,
    codigo_categoria BIGINT(20) NOT NULL,
    codigo_beneficiario BIGINT(20) NOT NULL,
    codigo_usuario BIGINT(20) NOT NULL,
	FOREIGN KEY (codigo_categoria) REFERENCES categoria(codigo),
    FOREIGN KEY (codigo_beneficiario) REFERENCES beneficiario(codigo),
	FOREIGN KEY (codigo_usuario) REFERENCES usuario(codigo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;