ALTER TABLE categoria
ADD codigo_usuario BIGINT(20) NOT NULL DEFAULT 1,
ADD CONSTRAINT fk_codigo_usuario FOREIGN KEY (codigo_usuario) REFERENCES usuario(codigo);