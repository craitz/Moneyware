var moneyware = moneyware || {};

moneyware.BeneficiarioCadastroRapido = (function() {
	
	function BeneficiarioCadastroRapido() {
		this.modal = $('#modalCadastroRapidoBeneficiario');
		this.botaoSalvar = this.modal.find('.js-modal-cadastro-beneficiario-salvar-btn');
		this.form = this.modal.find('form');
		this.url = this.form.attr('action');
		this.inputNomeBeneficiario = $('#nomeBeneficiario');
		this.containerMensagemErro = $('.js-mensagem-cadastro-rapido-beneficiario');
	}
	
	BeneficiarioCadastroRapido.prototype.iniciar = function() {
		this.form.on('submit', function(event) { event.preventDefault() });
		this.modal.on('shown.bs.modal', onModalShow.bind(this));
		this.modal.on('hide.bs.modal', onModalClose.bind(this))
		this.botaoSalvar.on('click', onBotaoSalvarClick.bind(this));
	}
		
	function onModalShow() {
		this.inputNomeBeneficiario.focus();
	}

	function onModalClose() {
		this.inputNomeBeneficiario.val('');
		this.containerMensagemErro.addClass('hidden');
		this.form.find('.form-group').removeClass('has-error');
	}

	function onBotaoSalvarClick() {
		var nomeBeneficiario = this.inputNomeBeneficiario.val().trim();
		$.ajax({
			url : this.url,
			method : 'POST',
			contentType : 'application/json',
			data : JSON.stringify({
				nome : nomeBeneficiario
			}),
			error : onErroSalvandoBeneficiario.bind(this),
			success : onBeneficiarioSalva.bind(this),
		});
	}
	
	function onErroSalvandoBeneficiario(obj) {
		var mensagemErro = obj.responseText;
		this.containerMensagemErro.removeClass('hidden');
		this.containerMensagemErro.html('<span>' + mensagemErro + '</span>');
		this.form.find('.form-group').addClass('has-error');
	}

	function onBeneficiarioSalva(beneficiario) {
		var comboBeneficiario = $('#beneficiario');
		comboBeneficiario.append('<option value=' + beneficiario.codigo + '>' + beneficiario.nome
				+ '</option>');
		comboBeneficiario.val(beneficiario.codigo);
		this.modal.modal('hide');
	}
		
	return BeneficiarioCadastroRapido;
	
})();

$(function() {
	var beneficiarioCadastroRapido = new moneyware.BeneficiarioCadastroRapido();
	beneficiarioCadastroRapido.iniciar();
});
