package com.camilo.moneyware.controller.handler;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.camilo.moneyware.service.exception.CategoriaJaCadastradaException;

@ControllerAdvice
public class ControllerAdviceExceptionHandler {

	@ExceptionHandler(CategoriaJaCadastradaException.class)
	public ResponseEntity<String> handleCategoriaJaCadastradaException(CategoriaJaCadastradaException e) {
		return ResponseEntity.badRequest().body(e.getMessage());
	}
}
