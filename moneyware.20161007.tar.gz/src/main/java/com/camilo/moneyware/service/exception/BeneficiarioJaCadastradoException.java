package com.camilo.moneyware.service.exception;

public class BeneficiarioJaCadastradoException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
	public BeneficiarioJaCadastradoException(String message) {
		super(message);
	}

}