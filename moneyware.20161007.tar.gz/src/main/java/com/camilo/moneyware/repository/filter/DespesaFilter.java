package com.camilo.moneyware.repository.filter;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.camilo.moneyware.model.Beneficiario;
import com.camilo.moneyware.model.Categoria;
import com.camilo.moneyware.model.Usuario;

public class DespesaFilter {

	private BigDecimal valorDe;
	
	private BigDecimal valorAte;
	
	private LocalDate dataDe;	
	
	private LocalDate dataAte;	

	private Categoria categoria;
	
	private Beneficiario beneficiario;

	private String descricao;
	
	private Usuario usuario;
	
	public BigDecimal getValorDe() {
		return valorDe;
	}

	public void setValorDe(BigDecimal valorDe) {
		this.valorDe = valorDe;
	}

	public BigDecimal getValorAte() {
		return valorAte;
	}

	public void setValorAte(BigDecimal valorAte) {
		this.valorAte = valorAte;
	}
	
	public LocalDate getDataDe() {
		return dataDe;
	}

	public void setDataDe(LocalDate dataDe) {
		this.dataDe = dataDe;
	}

	public LocalDate getDataAte() {
		return dataAte;
	}

	public void setDataAte(LocalDate dataAte) {
		this.dataAte = dataAte;
	}

	public Categoria getCategoria() {
		return categoria;
	}

	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}

	public Beneficiario getBeneficiario() {
		return beneficiario;
	}

	public void setBeneficiario(Beneficiario beneficiario) {
		this.beneficiario = beneficiario;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
}
