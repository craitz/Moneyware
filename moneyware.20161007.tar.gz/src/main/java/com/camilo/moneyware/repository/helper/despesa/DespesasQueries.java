package com.camilo.moneyware.repository.helper.despesa;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.camilo.moneyware.dto.DespesaCategoria;
import com.camilo.moneyware.dto.DespesaMes;
import com.camilo.moneyware.model.Despesa;
import com.camilo.moneyware.repository.filter.DespesaFilter;

public interface DespesasQueries {

	public Page<Despesa> filtrar(DespesaFilter filtro, Pageable pageable);
	public List<DespesaMes> totalPorMes(Long codigoUsuario);
	public List<DespesaCategoria> totalPorCategoria(Long codigoUsuario, Integer mes);
	public BigDecimal getTotalMesAtual(Long codigoUsuario);
	public BigDecimal getMedia(Integer periodo, Long codigoUsuario);
	public BigDecimal getTotalSemana(Long codigoUsuario);
	public BigDecimal getTotalMes(Long codigoUsuario, Integer mes);
	public BigDecimal valorTotal(DespesaFilter filtro) ;
}
