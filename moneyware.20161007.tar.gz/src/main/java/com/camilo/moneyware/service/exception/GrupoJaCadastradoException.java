package com.camilo.moneyware.service.exception;

public class GrupoJaCadastradoException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
	public GrupoJaCadastradoException(String message) {
		super(message);
	}

}