var moneyware = moneyware || {};

moneyware.GraficoDespesasPorMes = (function() {

	function GraficoDespesasPorMes() {
		this.ctx = $('#graficoDespesasPorMes')[0].getContext('2d');
	}

	GraficoDespesasPorMes.prototype.iniciar = function() {
		$.ajax({
			url: 'despesas/totalPorMes',
			method: 'GET', 
			success: onDadosRecebidos.bind(this)
		});
	}

	function onDadosRecebidos(despesaMes) {
		var meses = [];
		var valores = [];
		despesaMes.forEach(function(obj) {
			meses.unshift(obj.mes);
			valores.unshift(obj.total);
		});

		var graficoDespesasPorMes = new Chart(this.ctx, {
			type : 'line',
			data : {
				labels : meses,
				datasets : [ {
					label : 'Últimos 6 meses',
					backgroundColor : "rgba(26,179,148,0.5)",
					pointBorderColor : "rgba(26,179,148,1)",
					pointBackgroundColor : "transparent",
					data : valores
				} ]
			},
		});
	}

	return GraficoDespesasPorMes;

}());

moneyware.GraficoPizza = (function() {
	
	var graficoPizza;

	function GraficoPizza() {
		this.ctx = $('#graficoPizza')[0].getContext('2d');
	}

	GraficoPizza.prototype.iniciar = function(mes) {
		$.ajax({
			url: 'despesas/totalPorCategoria/'+mes,
			method: 'GET', 
			success: onDadosRecebidos.bind(this)
		});
	}

	function onDadosRecebidos(despesaCategoria) {
		var categorias = [];
		var valores = [];
		despesaCategoria.forEach(function(obj) {
			categorias.unshift(obj.categoria);
			valores.unshift(obj.total);
		});

		//para o chart.js redesenhar o gráfico do zero
		//sem pintar um por cima do outro
		if (graficoPizza !== undefined)
			graficoPizza.destroy();
		
		graficoPizza = new Chart(this.ctx, {
			type: 'doughnut',
			data : { labels: categorias,
				    datasets: [
				        {
				            data: valores,
				            backgroundColor: [
				            	'#FF6384',
				            	'#4BC0C0',
				            	'#36A2EB',
				            	'#FFCE56',
				            	'#E7E9ED'
				            ]
				        }]
				}
		});
		
		graficoPizza.update();
	}
	
	return GraficoPizza;

}());

$(function() {
	
	var graficoDespesasPorMes = new moneyware.GraficoDespesasPorMes();
	var graficoPizza = new moneyware.GraficoPizza();
	var comboMeses = $('.js-meses-selection');	
	var mesSelecionado = comboMeses['0'].selectedIndex+1;
	console.log(comboMeses);

	comboMeses.on('change', atualizaDashboard);

	graficoDespesasPorMes.iniciar();
	graficoPizza.iniciar(mesSelecionado);
});

function atualizaDashboard(e) {
	var mesSelecionado = e.currentTarget.value;

	$('.js-card-total-mes-label').html(e.currentTarget[mesSelecionado-1].label);
	
	carregaGraficoDespesasPorCategoria(mesSelecionado);
	carregaCardDespesaTotalNoMes(mesSelecionado);
}
	
function carregaGraficoDespesasPorCategoria(mes) {
	graficoPizza = new moneyware.GraficoPizza();
	graficoPizza.iniciar(mes);
}

function carregaCardDespesaTotalNoMes(mes) {
	$.ajax({
		url: 'despesas/totalMes/'+mes,
		method: 'GET', 
		success: onDadosRecebidos
	});
	
	function onDadosRecebidos(total) {
		var trader = $('#currencyTrader');
		trader.val(total);
		
		trader.priceFormat({
		    prefix: 'R$ ',
		    centsSeparator: ',',
		    thousandsSeparator: '.'
		});

	    $('.js-card-total-mes').html('- ' + trader.val());
	}
}
