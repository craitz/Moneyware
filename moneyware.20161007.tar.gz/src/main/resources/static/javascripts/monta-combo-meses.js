var comboMeses = $('.js-meses-selection');

var monthNames = [ "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
	"Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro" ];

var mesAtual = new Date().getMonth();

function montaCombo() {
	for (var i = 0; i <  monthNames.length; i++) {
		if (i == mesAtual) {
			comboMeses.append('<option value="' + (i+1) + '" selected>' + monthNames[i] + '</option>');
		} else {
			comboMeses.append('<option value="' + (i+1) + '">' + monthNames[i] + '</option>');
		}
	}
}

$(function() {
	montaCombo();
});