package com.camilo.moneyware.controller.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.util.StringUtils;

import com.camilo.moneyware.model.Beneficiario;

public class BeneficiarioConverter implements Converter<String, Beneficiario> {

	@Override
	public Beneficiario convert(String codigo) {
		if (!StringUtils.isEmpty(codigo)) {
			Beneficiario beneficiario = new Beneficiario();
			beneficiario.setCodigo(Long.valueOf(codigo));
			return beneficiario;
		}
		
		return null;
	}

}
