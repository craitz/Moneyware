package com.camilo.moneyware.repository.helper.despesa;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.camilo.moneyware.dto.DespesaCategoria;
import com.camilo.moneyware.dto.DespesaMes;
import com.camilo.moneyware.model.Despesa;
import com.camilo.moneyware.repository.filter.DespesaFilter;
import com.camilo.moneyware.repository.pagination.PaginacaoUtil;

public class DespesasImpl implements DespesasQueries {

	@PersistenceContext
	private EntityManager manager;
	
	@Autowired
	PaginacaoUtil paginacaoUtil;

	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	@Override
	public Page<Despesa> filtrar(DespesaFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Despesa.class);

		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria);

		return new PageImpl<>(criteria.list(), pageable, total(filtro));
	}

	private void adicionarFiltro(DespesaFilter filtro, Criteria criteria) {
			criteria.add(Restrictions.eq("usuario", filtro.getUsuario()));
			
			if (filtro.getValorDe() != null) {
				criteria.add(Restrictions.ge("valor", filtro.getValorDe()));
			}

			if (filtro.getValorAte() != null) {
				criteria.add(Restrictions.le("valor", filtro.getValorAte()));
			}

			if (!StringUtils.isEmpty(filtro.getDataDe())) {
				criteria.add(Restrictions.ge("data", filtro.getDataDe()));
			}
			
			if (!StringUtils.isEmpty(filtro.getDataAte())) {
				criteria.add(Restrictions.le("data", filtro.getDataAte()));
			}

			if (isCategoriaPresente(filtro)) {
				criteria.add(Restrictions.eq("categoria", filtro.getCategoria()));
			}

			if (isBeneficiarioPresente(filtro)) {
				criteria.add(Restrictions.eq("beneficiario", filtro.getBeneficiario()));
			}

			if (!StringUtils.isEmpty(filtro.getDescricao())) {
				criteria.add(Restrictions.ilike("descricao", filtro.getDescricao(), MatchMode.ANYWHERE));
			}
	}
	
	private boolean isCategoriaPresente(DespesaFilter filtro) {
		return filtro.getCategoria() != null && filtro.getCategoria().getCodigo() != null;
	}
	
	private boolean isBeneficiarioPresente(DespesaFilter filtro) {
		return filtro.getBeneficiario() != null && filtro.getBeneficiario().getCodigo() != null;
	}

	@Transactional(readOnly = true)
	@Override
	public BigDecimal valorTotal(DespesaFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Despesa.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.sum("valor"));
		Optional<BigDecimal> totalOptional = Optional.ofNullable((BigDecimal) criteria.uniqueResult());
		return totalOptional.orElse(BigDecimal.ZERO);
	}

	private Long total(DespesaFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Despesa.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<DespesaMes> totalPorMes(Long codigoUsuario) {
		List<DespesaMes> despesasMes = manager.createNamedQuery("Despesas.totalPorMes")
				.setParameter("codigo", codigoUsuario)
				.getResultList();
		
		LocalDate hoje = LocalDate.now();
		for (int i = 1; i <= 6; i++) {
			String mesIdeal = String.format("%d/%02d", hoje.getYear(), hoje.getMonthValue());
			
			boolean possuiMes = despesasMes.stream().filter(v -> v.getMes().equals(mesIdeal)).findAny().isPresent();
			if (!possuiMes) {
				despesasMes.add(i - 1, new DespesaMes(mesIdeal, BigDecimal.ZERO));
			}
			
			hoje = hoje.minusMonths(1);
		}
		
		return despesasMes;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<DespesaCategoria> totalPorCategoria(Long codigoUsuario, Integer mes) {
		List<DespesaCategoria> despesasCategoria = manager.createNamedQuery("Despesas.totalPorCategoria")
				.setParameter("codigo", codigoUsuario)
				.setParameter("mes", mes)
				.getResultList();

		return despesasCategoria;
	}

	@Override
	public BigDecimal getTotalMesAtual(Long codigoUsuario) {
		Optional<BigDecimal> total = Optional.ofNullable(
				manager.createQuery(
						"SELECT SUM(valor)"
						+ "FROM Despesa "
						+ "WHERE YEAR(data) = YEAR(NOW()) "
						+ "AND MONTH(data) = MONTH(NOW()) "
						+ "AND codigo_usuario = :codigo"
						, BigDecimal.class)
				.setParameter("codigo", codigoUsuario)
				.getSingleResult());

		return total.orElse(BigDecimal.ZERO);
	}
	
	@Override
	public BigDecimal getMedia(Integer periodo, Long codigoUsuario) {
		Optional<BigDecimal> total = Optional.ofNullable(manager
				.createQuery(
						"SELECT SUM(valor)/:periodo "
						+ "FROM Despesa "
						+ "WHERE TIMESTAMPDIFF(MONTH, data, NOW()) < :periodo "
						+ "AND codigo_usuario = :codigo"
						, BigDecimal.class)
				.setParameter("periodo", BigDecimal.valueOf(periodo))
				.setParameter("codigo", codigoUsuario)
				.getSingleResult());
		
		return total.orElse(BigDecimal.ZERO);
	}	

	@Override
	public BigDecimal getTotalSemana(Long codigoUsuario) {
		Optional<BigDecimal> total = Optional.ofNullable(
				manager.createQuery(
						"SELECT SUM(valor) "
						+ "FROM Despesa "
						+ "WHERE YEAR(data) = YEAR(NOW()) "
						+ "AND MONTH(data) = MONTH(NOW()) "
						+ "AND WEEK(data) = WEEK(NOW()) "
						+ "AND codigo_usuario = :codigo"
						, BigDecimal.class)
				.setParameter("codigo", codigoUsuario)
				.getSingleResult());
		
		return total.orElse(BigDecimal.ZERO);
	}

	@Override
	public BigDecimal getTotalMes(Long codigoUsuario, Integer mes) {
		Optional<BigDecimal> total = Optional.ofNullable(
				manager.createQuery(
						"SELECT SUM(valor) "
						+ "FROM Despesa "
						+ "WHERE YEAR(data) = YEAR(NOW()) "
						+ "AND MONTH(data) = :mes "
						+ "AND codigo_usuario = :codigo"
						, BigDecimal.class)
				.setParameter("codigo", codigoUsuario)
				.setParameter("mes", mes)
				.getSingleResult());
		
		return total.orElse(BigDecimal.ZERO);
	}	
}
