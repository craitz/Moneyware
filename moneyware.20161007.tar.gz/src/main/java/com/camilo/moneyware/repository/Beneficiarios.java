package com.camilo.moneyware.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.camilo.moneyware.model.Beneficiario;
import com.camilo.moneyware.model.Categoria;
import com.camilo.moneyware.repository.helper.beneficiario.BeneficiariosQueries;

@Repository
public interface Beneficiarios extends JpaRepository<Beneficiario, Long>, BeneficiariosQueries {

	public Optional<Beneficiario> findByNomeIgnoreCase(String nome);
	public List<Beneficiario> findAllByOrderByNomeAsc();
}
