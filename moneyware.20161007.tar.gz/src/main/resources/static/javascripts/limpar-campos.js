moneyware = moneyware || {};

moneyware.LimpaCampos = (function() {
	
	function LimpaCampos() {
		this.botaoLimpar = $('#btn-limpar');
	}

	LimpaCampos.prototype.iniciar = function() {
		this.botaoLimpar.on('click', onLimparPesquisa.bind(this));
	}
	
	function onLimparPesquisa(e) {
		e.preventDefault();
		$('form').trigger("reset");
	}
	
	return LimpaCampos;
})();

$(function() {
	var limpaCampos = new moneyware.LimpaCampos();
	limpaCampos.iniciar();
});
