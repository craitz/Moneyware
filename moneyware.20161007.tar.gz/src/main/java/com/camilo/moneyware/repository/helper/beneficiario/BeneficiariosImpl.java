package com.camilo.moneyware.repository.helper.beneficiario;

import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.camilo.moneyware.model.Beneficiario;
import com.camilo.moneyware.repository.filter.BeneficiarioFilter;
import com.camilo.moneyware.repository.pagination.PaginacaoUtil;

public class BeneficiariosImpl implements BeneficiariosQueries {

	@PersistenceContext
	private EntityManager manager;
	
	@Autowired
	PaginacaoUtil paginacaoUtil;

	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	@Override
	public Page<Beneficiario> filtrar(BeneficiarioFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Beneficiario.class);

		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria);

		return new PageImpl<>(criteria.list(), pageable, total(filtro));
	}

	private void adicionarFiltro(BeneficiarioFilter filtro, Criteria criteria) {
		if (filtro != null) {
			if (!StringUtils.isEmpty(filtro.getNome())) {
				criteria.add(Restrictions.ilike("nome", filtro.getNome(), MatchMode.ANYWHERE));
			}
		}
	}

	private Long total(BeneficiarioFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Beneficiario.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}

	@Override
	public Long getNumeroTotal() {
		Optional<Long> total = Optional.ofNullable(manager.createQuery("SELECT COUNT(*) FROM Beneficiario", Long.class).getSingleResult());
		return total.orElse(0L);
	}
}
