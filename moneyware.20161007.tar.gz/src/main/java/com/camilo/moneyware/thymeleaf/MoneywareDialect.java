package com.camilo.moneyware.thymeleaf;

import java.util.HashSet;
import java.util.Set;

import org.thymeleaf.dialect.AbstractProcessorDialect;
import org.thymeleaf.processor.IProcessor;
import org.thymeleaf.standard.StandardDialect;

import com.camilo.moneyware.thymeleaf.processor.ClassForErrorAttributeTagProcessor;
import com.camilo.moneyware.thymeleaf.processor.MenuAttributeTagProcessor;
import com.camilo.moneyware.thymeleaf.processor.MessageElementTagProcessor;
import com.camilo.moneyware.thymeleaf.processor.OrderElementTagProcessor;
import com.camilo.moneyware.thymeleaf.processor.PaginationElementTagProcessor;
import com.camilo.moneyware.thymeleaf.processor.PesquisaLimpaFormElementTagProcessor;

public class MoneywareDialect extends AbstractProcessorDialect {

	public MoneywareDialect() {
		super("Camilo Moneyware", "moneyware", StandardDialect.PROCESSOR_PRECEDENCE);
	}
	
	@Override
	public Set<IProcessor> getProcessors(String dialectPrefix) {
		final Set<IProcessor> processadores = new HashSet<>();
		processadores.add(new ClassForErrorAttributeTagProcessor(dialectPrefix));
		processadores.add(new MessageElementTagProcessor(dialectPrefix));
		processadores.add(new OrderElementTagProcessor(dialectPrefix));
		processadores.add(new PaginationElementTagProcessor(dialectPrefix));
		processadores.add(new MenuAttributeTagProcessor(dialectPrefix));
		processadores.add(new PesquisaLimpaFormElementTagProcessor(dialectPrefix));
		return processadores;
	}

}
