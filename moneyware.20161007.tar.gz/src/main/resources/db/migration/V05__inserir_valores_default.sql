INSERT INTO usuario (nome, email, senha, ativo) VALUES ('Admin', 'admin@moneyware.com', '$2a$10$g.wT4R0Wnfel1jc/k84OXuwZE02BlACSLfWy6TycGPvvEKvIm86SG', 1);

INSERT INTO grupo (codigo, nome) VALUES (1, 'Administrador');
INSERT INTO grupo (codigo, nome) VALUES (2, 'Cliente');

INSERT INTO permissao (codigo, nome) VALUES (1, 'ROLE_CADASTRAR_DESPESA');
INSERT INTO permissao (codigo, nome) VALUES (2, 'ROLE_CADASTRAR_USUARIO');
INSERT INTO permissao (codigo, nome) VALUES (3, 'ROLE_CADASTRAR_BENEFICIARIO');
INSERT INTO permissao (codigo, nome) VALUES (4, 'ROLE_CADASTRAR_CATEGORIA');

INSERT INTO grupo_permissao (codigo_grupo, codigo_permissao) VALUES (1, 1);
INSERT INTO grupo_permissao (codigo_grupo, codigo_permissao) VALUES (1, 2);
INSERT INTO grupo_permissao (codigo_grupo, codigo_permissao) VALUES (1, 3);
INSERT INTO grupo_permissao (codigo_grupo, codigo_permissao) VALUES (1, 4);

INSERT INTO usuario_grupo (codigo_usuario, codigo_grupo) VALUES (1, 1);