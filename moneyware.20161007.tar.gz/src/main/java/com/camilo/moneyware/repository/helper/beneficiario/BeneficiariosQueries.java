package com.camilo.moneyware.repository.helper.beneficiario;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.camilo.moneyware.model.Beneficiario;
import com.camilo.moneyware.repository.filter.BeneficiarioFilter;

public interface BeneficiariosQueries {

	public Page<Beneficiario> filtrar(BeneficiarioFilter filtro, Pageable pageable);

	public Long getNumeroTotal();
}
