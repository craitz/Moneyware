package com.camilo.moneyware.model;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.camilo.moneyware.repository.Usuarios;

@Service
public class Utilidades {
	
	@Autowired
	private Usuarios usuarios;
	
	public Usuario getUsuarioLogado() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Usuario usuarioLogado = usuarios.findByEmail(((Principal) authentication.getPrincipal()).getName()).get();
		return usuarioLogado;
	}
}
